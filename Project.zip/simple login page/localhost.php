<?php
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $mysql_db = 'adatabase';
        mysql_connect($host,$user,$pass); 
        mysql_select_db($mysql_db);
 ?>