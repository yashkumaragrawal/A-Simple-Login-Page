<html> 
<head>
<link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script> 
</head>
<body> 
      <div class="navbar navbar-inverse">
         <div class="container-fluid">
             <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar"> 
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
               <a href="index.php" class="navbar-brand">MY SITE</a>
             </div>
            <div class="collapse navbar-collapse" id="mainNavBar">
             <ul class="nav navbar-nav navbar-right">
                 <li><a href="resiter.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
                 <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
              </ul>    
 </div>
         </div>
      </div>

</body>
</html>
